#ifndef FILA_H
#define FILA_H

#define TAM_MAX 50000

typedef struct {
    int dados[TAM_MAX];
    int inicio;   
    int fim;      
    int qtd;     
} Fila;

void inicializar(Fila *f);
int  estaVazia(Fila *f);
int  estaCheia(Fila *f);
int  inserir(Fila *f, int valor);   
int  remover(Fila *f, int *valor);  
void listar(Fila *f);               

/* implementada no main.c */
void exibirDado(int p);

#endif
