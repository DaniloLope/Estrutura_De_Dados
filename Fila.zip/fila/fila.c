#include <stdio.h>
#include "fila.h"

void inicializar(Fila *f) {
    f->inicio = 0;
    f->fim = 0;
    f->qtd = 0;
}

int estaVazia(Fila *f) {
    return f->qtd == 0;
}

int estaCheia(Fila *f) {
    return f->qtd == TAM_MAX;
}

int inserir(Fila *f, int valor) {
    if (estaCheia(f)) {
        return 0;
    }
    f->dados[f->fim] = valor;
    f->fim = (f->fim + 1) % TAM_MAX; 
    f->qtd++;
    return 1;
}

int remover(Fila *f, int *valor) {
    if (estaVazia(f)) {
        return 0;
    }
    *valor = f->dados[f->inicio];
    f->inicio = (f->inicio + 1) % TAM_MAX;
    f->qtd--;
    return 1;
}

void listar(Fila *f) {
    int i, pos = f->inicio;
    for (i = 0; i < f->qtd; i++) {
        exibirDado(f->dados[pos]);
        pos = (pos + 1) % TAM_MAX;
    }
}
