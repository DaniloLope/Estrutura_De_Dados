#include <stdio.h>
#include "pilha.h"

void inicializar(Pilha *p) {
    p->topo = -1;
}

int estaVazia(Pilha *p) {
    return p->topo == -1;
}

int estaCheia(Pilha *p) {
    return p->topo == TAM_MAX - 1;
}

int inserir(Pilha *p, int valor) {
    if (estaCheia(p)) {
        return 0;
    }
    p->topo++;
    p->dados[p->topo] = valor;
    return 1;
}

int remover(Pilha *p, int *valor) {
    if (estaVazia(p)) {
        return 0;
    }
    *valor = p->dados[p->topo];
    p->topo--;
    return 1;
}

void listar(Pilha *p) {
    int i;
    for (i = p->topo; i >= 0; i--) {
        exibirDado(p->dados[i]);
    }
}
