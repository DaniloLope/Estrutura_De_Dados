#ifndef PILHA_H
#define PILHA_H

#define TAM_MAX 50000

typedef struct {
    int dados[TAM_MAX];
    int topo;
} Pilha;

void inicializar(Pilha *p);
int  estaVazia(Pilha *p);
int  estaCheia(Pilha *p);
int  inserir(Pilha *p, int valor); 
int  remover(Pilha *p, int *valor); 
void listar(Pilha *p); 

void exibirDado(int p);

#endif
