#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "lista.h"

int tamanho = TAM_MAX;

int numeroAleatorio(int low, int high) {
    int k;
    double d;
    d = (double) rand() / ((double) RAND_MAX + 1);
    k = d * (high - low + 1);
    return low + k;
}

int obterDado() {
    return numeroAleatorio(0, tamanho);
}

void exibirDado(int p) {
    printf("\nElemento: %i", p);
}


int lerInteiro() {
    int n;
    if (scanf("%d", &n) != 1) {
        while (getchar() != '\n');
        return -1;
    }
    return n;
}

int lerQuantidade() {
    int q;
    do {
        printf("Digite a quantidade de elementos para testar: ");
        q = lerInteiro();
    } while (q < 1 || q > TAM_MAX);
    return q;
}

int main() {
    Lista lista;
    double start, finish, elapsed;
    int quantidade;
    int i, p, opcao;

    srand((unsigned) time(NULL));
    inicializar(&lista);

    quantidade = lerQuantidade();

    do {
        printf("\n1 - INSERCAO");
        printf("\n2 - REMOCAO");
        printf("\n3 - LISTAGEM");
        printf("\n4 - Alterar quantidade de elementos para testar");
        printf("\n0 - Sair\n");
        opcao = lerInteiro();

        switch (opcao) {
            case 1:
                start = (double) clock();
                for (i = 0; i < quantidade; i++) {
                    p = obterDado();
                    if (!inserir(&lista, p)) {
                        printf("\nLista cheia! Inseridos apenas %d elementos.", i);
                        break;
                    }
                    exibirDado(p);
                }
                finish = (double) clock();
                elapsed = finish - start;
                printf("\nForam utilizados %.2f clocks", elapsed);
                break;

            case 2:
                start = (double) clock();
                for (i = 0; i < quantidade; i++) {
                    if (!remover(&lista, &p)) {
                        printf("\nLista vazia! Removidos apenas %d elementos.", i);
                        break;
                    }
                    exibirDado(p);
                }
                finish = (double) clock();
                elapsed = finish - start;
                printf("\nForam utilizados %.2f clocks", elapsed);
                break;

            case 3:
                if (estaVazia(&lista)) {
                    printf("\nLista vazia! Nada para listar.");
                    break;
                }
                start = (double) clock();
                listar(&lista);
                finish = (double) clock();
                elapsed = finish - start;
                printf("\nForam utilizados %.2f clocks", elapsed);
                break;

            case 4:
                quantidade = lerQuantidade();
                break;

            case 0:
                printf("\nexit\n");
                break;

            default:
                printf("\nOpcao invalida!");
        }
    } while (opcao != 0);

    return 0;
}
