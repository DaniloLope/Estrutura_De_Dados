#ifndef LISTA_H
#define LISTA_H

#define TAM_MAX 50000

typedef struct {
    int dados[TAM_MAX];
    int qtd;    
} Lista;

void inicializar(Lista *l);
int  estaVazia(Lista *l);
int  estaCheia(Lista *l);
int  inserir(Lista *l, int valor);   
int  remover(Lista *l, int *valor);  
void listar(Lista *l);               


void exibirDado(int p);

#endif
