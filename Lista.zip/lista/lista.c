#include <stdio.h>
#include "lista.h"

void inicializar(Lista *l) {
    l->qtd = 0;
}

int estaVazia(Lista *l) {
    return l->qtd == 0;
}

int estaCheia(Lista *l) {
    return l->qtd == TAM_MAX;
}

int inserir(Lista *l, int valor) {
    if (estaCheia(l)) {
        return 0;
    }
    l->dados[l->qtd] = valor;
    l->qtd++;
    return 1;
}

int remover(Lista *l, int *valor) {
    int i;
    if (estaVazia(l)) {
        return 0;
    }
    *valor = l->dados[0];
    for (i = 1; i < l->qtd; i++) {
        l->dados[i - 1] = l->dados[i];
    }
    l->qtd--;
    return 1;
}

void listar(Lista *l) {
    int i;
    for (i = 0; i < l->qtd; i++) {
        exibirDado(l->dados[i]);
    }
}
