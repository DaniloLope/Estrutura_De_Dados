
#include <stdio.h>
#include "fila.h"

void inicializar(Fila *f) {
    f->inicio = 0;
    f->fim = 0;
    f->qtd = 0;
}

int estaVazia(Fila *f) {
    return f->qtd == 0;
}

int estaCheia(Fila *f) {
    return f->fim == TAM_MAX;
}

int inserir(Fila *f, int valor) {
    if (estaCheia(f)) {
        return 0;
    }

    f->dados[f->fim] = valor;
    f->fim++;
    f->qtd++;

    return 1;
}

int remover(Fila *f, int *valor) {
    if (estaVazia(f)) {
        return 0;
    }

    *valor = f->dados[f->inicio];
    f->inicio++;
    f->qtd--;

    return 1;
}

void listar(Fila *f) {
    int i;

    for (i = f->inicio; i < f->fim; i++) {
        exibirDado(f->dados[i]);
    }
}
