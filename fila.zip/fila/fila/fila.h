#ifndef FILA_H
#define FILA_H

#define TAM_MAX 50000

typedef struct {
    int dados[TAM_MAX];
    int inicio;   /* posicao do primeiro elemento */
    int fim;      /* posicao onde sera inserido o proximo elemento */
    int qtd;      /* quantidade de elementos na fila */
} Fila;

void inicializar(Fila *f);
int  estaVazia(Fila *f);
int  estaCheia(Fila *f);
int  inserir(Fila *f, int valor);   /* retorna 1 se inseriu, 0 se cheia */
int  remover(Fila *f, int *valor);  /* retorna 1 se removeu, 0 se vazia */
void listar(Fila *f);               /* percorre a fila chamando exibirDado */

/* implementada no main.c */
void exibirDado(int p);

#endif
